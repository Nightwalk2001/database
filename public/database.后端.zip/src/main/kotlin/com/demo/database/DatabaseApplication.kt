package com.demo.database

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.data.r2dbc.repository.Query
import org.springframework.data.r2dbc.repository.R2dbcRepository
import org.springframework.data.relational.core.mapping.Table
import org.springframework.data.relational.core.sql.Select
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Controller
import org.springframework.stereotype.Repository
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux

// 不用管，入口函数
@SpringBootApplication
class DatabaseApplication

fun main(args: Array<String>) {
    runApplication<DatabaseApplication>(*args)
}

// 定义存储的数据类型，可以不使用所有列，其实人类基因组数据大概有三十列
@Table("concat_hg38")
data class Hg(
    val chrom: String,
    val feature: String?,
    val start: Int,
    val end: Int,
    val strand: String?,
    val geneName: String,
)

@Repository
interface HgRepository : R2dbcRepository<Hg, String> {
    // 看函数的名字，这个函数会自动生成一个sql语句
    fun findAllByGeneNameAndFeature(gene: String, feature: String): Flux<Hg>
}

@Service
class DemoService(
    private val hgRepo: HgRepository
) {
    fun getExons(gene: String, feature: String) =
        hgRepo.findAllByGeneNameAndFeature(gene, feature)
}

@RestController
class DemoController(
    private val service: DemoService
) {
    // 这个是给前端用的api接口，gene是前端传的变量
    @GetMapping("/exons/{gene}")
    fun getExons(@PathVariable gene: String) = service.getExons(gene, "exon")
}
