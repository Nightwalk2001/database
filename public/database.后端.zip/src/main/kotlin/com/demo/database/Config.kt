package com.demo.database

import com.github.jasync.r2dbc.mysql.JasyncConnectionFactory
import com.github.jasync.sql.db.mysql.pool.MySQLConnectionFactory
import io.r2dbc.spi.ConnectionFactory
import org.springframework.context.annotation.Configuration
import org.springframework.core.Ordered
import org.springframework.core.annotation.Order
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.server.reactive.ServerHttpRequest
import org.springframework.http.server.reactive.ServerHttpResponse
import org.springframework.stereotype.Component
import org.springframework.web.cors.reactive.CorsUtils
import org.springframework.web.server.ServerWebExchange
import org.springframework.web.server.WebFilter
import org.springframework.web.server.WebFilterChain
import reactor.core.publisher.Mono
import com.github.jasync.sql.db.Configuration as JasyncSqlDbConfiguration

@Configuration
@EnableR2dbcRepositories
class MysqlConfiguration : AbstractR2dbcConfiguration() {
    override fun connectionFactory(): ConnectionFactory {
        // 这两行是数据库的用户名，ip，端口，密码，数据库名字
        val conf = JasyncSqlDbConfiguration(
            "root", "127.0.0.1", 3306, "root", "fusion"
        )
        return JasyncConnectionFactory(MySQLConnectionFactory(conf))
    }
}

// 下面这一大串，没有什么特殊意义，由于浏览器的跨域策略需要这部分代码
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
class CorsFilter : WebFilter {
    override fun filter(exchange: ServerWebExchange, chain: WebFilterChain): Mono<Void> {
        val request: ServerHttpRequest = exchange.request
        val response: ServerHttpResponse = exchange.response
        if (CorsUtils.isCorsRequest(request)) {
            val headers: HttpHeaders = response.headers
            headers.add("Access-Control-Allow-Origin", ALLOWED_ORIGIN)
            headers.add("Access-Control-Allow-Methods", ALLOWED_METHODS)
            headers.add("Access-Control-Max-Age", MAX_AGE)
            headers.add("Access-Control-Allow-Headers", ALLOWED_HEADERS)
            if (request.method === HttpMethod.OPTIONS) {
                response.statusCode = HttpStatus.OK
                return Mono.empty()
            }
        }
        return chain.filter(exchange)
    }

    companion object {
        private const val ALLOWED_HEADERS =
            "x-requested-with, Content-Type, credential, X-XSRF-TOKEN"
        private const val ALLOWED_METHODS = "GET, PUT, POST, DELETE, OPTIONS"
        // 通常这一行不用改，但是如果你的前端项目url不一样，就要改成你自己的
        private const val ALLOWED_ORIGIN = "http://localhost:3000"
        private const val MAX_AGE = "3600"
    }
}

