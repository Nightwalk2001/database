declare type Hg = {
    chrom: string
    feature: string
    start: number
    end: number
    strand: string
    geneName: string
}
