declare type Lnc = {
    sample: string
    value: number
}